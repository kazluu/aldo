"""
Aldo - Work Hours Tracker and Invoice Generator for Freelancers
"""

__version__ = "1.0.0"